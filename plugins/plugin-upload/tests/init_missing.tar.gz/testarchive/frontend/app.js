var plugin = {};

(function (plugin) {
	
}(plugin));

module.exports = plugin;