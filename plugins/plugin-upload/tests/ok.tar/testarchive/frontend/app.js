var plugin = {};

(function (plugin) {

	plugin.init = function(app, countlyDb){
		
	};
}(plugin));

module.exports = plugin;