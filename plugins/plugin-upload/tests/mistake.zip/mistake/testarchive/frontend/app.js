var plugin = {};

(function (plugin) {
	plugin.init = function(app, countlyDb){
		setTimeout(function(novar) {
            adfadfadfadfa
            
        },1000);
	};
}(plugin));

module.exports = plugin;