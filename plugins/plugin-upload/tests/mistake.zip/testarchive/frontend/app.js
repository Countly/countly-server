var plugin = {};

(function (plugin) {
c opsayup[
	plugin.init = function(app, countlyDb){
		shbcuipJ
        hvjvj
        bjbbjkbk
	};
}(plugin));

module.exports = plugin;